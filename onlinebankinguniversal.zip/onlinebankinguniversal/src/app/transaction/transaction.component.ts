import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
//@ts-ignore
import * as data from '../../assets/opec.json';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { EditViewComponent } from './edit-view/edit-view.component';


@Component({
  selector: 'bofa-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.less']
})
export class TransactionComponent implements OnInit, AfterViewInit {

  _tblData: any;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  _tableSource = new MatTableDataSource();
  displayedColumns: string[] = ["0", "1", "edit", "delete"];
  constructor(private dialog: MatDialog) { }

  ngOnInit() {
    this._tblData = data.dataset.data;
    this._tableSource.data = this._tblData;
    console.log(this._tblData);
  }
  ngAfterViewInit() {
    debugger;
    this._tableSource.paginator = this.paginator;
    this._tableSource.sort = this.sort;
  }

  openDialog(_data) {
    const dialogRef = this.dialog.open(EditViewComponent, {

      width: '600px',
      data: {
        date: _data[0],
        value: _data[1]
      }
    });

    dialogRef.afterClosed().subscribe(x => {
      if (x)
        console.log(x);
    });

  }

}
