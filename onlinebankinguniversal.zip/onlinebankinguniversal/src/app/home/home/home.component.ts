import { Component, OnInit } from '@angular/core';
import { MenuService } from 'src/app/services/menu.service';

@Component({
  selector: 'bofa-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less']
})
export class HomeComponent implements OnInit {

  _data:any;
  constructor(private menuSvc: MenuService) { }

  ngOnInit() {
    this.menuSvc.getMenuItems().subscribe(items=>{
      debugger;
      this._data = items;
    });
  }


}
