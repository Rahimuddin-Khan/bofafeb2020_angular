import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.less']
})
export class AddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
