import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.less']
})
export class RequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
