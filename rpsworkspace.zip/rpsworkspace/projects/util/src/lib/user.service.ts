import { Injectable } from '@angular/core';

@Injectable()
export class UserService {

  constructor() { }
  getData() {
    return ["BOA", "CITI", "JPMORGON", "LYODS"];
  }
}
