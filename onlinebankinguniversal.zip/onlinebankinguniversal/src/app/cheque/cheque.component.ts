import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-cheque',
  templateUrl: './cheque.component.html',
  styleUrls: ['./cheque.component.less']
})
export class ChequeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
