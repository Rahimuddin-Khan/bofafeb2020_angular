import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { NgForm } from '@angular/forms';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { AuthConfig, OAuthService, JwksValidationHandler } from 'angular-oauth2-oidc';

export const authConfig: AuthConfig = {
  issuer: 'https://dev-430118.okta.com/oauth2/default',
  clientId: "0oa248uipXTvY6eZK4x6",
  redirectUri: "http://localhost:8085/"
}

@Component({
  selector: 'bofa-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})

export class LoginComponent implements OnInit {

  constructor(private loginSvc: LoginService, private router: Router, private authSvc: AuthenticationService, private oauthService:OAuthService) {
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.loadDiscoveryDocumentAndTryLogin();
  }
  user: User = new User("eswaribala", "vignesh");
  ngOnInit() {
  }
  ologin(event) {
    //event.preventDefault();
    
    this.oauthService.initImplicitFlow();
    //this.router.navigate(["http://localhost:8085/Home/"]);

  }
  get givenName() {
    const claims = this.oauthService.getIdentityClaims();
    if (!claims) {
      return null;
    }
    return claims['name'];
  }
  logout() {
    this.oauthService.logOut();
  }
  onSubmit(f: NgForm) {
    this.loginSvc.checkUserExistence(this.user).subscribe(x => {
      this.onReset();
      if (x.email != null) {
        this.authSvc.token = x.email;
        if (this.authSvc.isLoggedIn) {
          this.router.navigate(["/Home"]);
        }
        else
          this.router.navigate(["/Login"]);
      }
    }
    );
  }
  onReset() {
    this.user = new User('', '');
  }

}
