import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.less']
})
export class EditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
