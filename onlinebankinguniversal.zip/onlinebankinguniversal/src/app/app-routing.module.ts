import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home/home.component';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { TransactionComponent } from './transaction/transaction.component';
import { ChequeComponent } from './cheque/cheque.component';
import { AddressComponent } from './address/address.component';
import { RequestComponent } from './request/request.component';


const routes: Routes = [
  { path: "Login", component: LoginComponent },
  {
    path: "Home", component: HomeComponent, children: [

      {
        path: "AccountSummary", component: AccountsummaryComponent, children:
          [
            { path: "Transactions", component: TransactionComponent }
          ]
      },
      {
        path: "Requests", component: RequestComponent, children:
          [
            { path: "Cheque", component: ChequeComponent },
            { path: "Address", component: AddressComponent }
          ]
      },
      { path: "FT", loadChildren: () => import("./fundtransfer/fundtransfer.module").then(x => x.FundtransferModule) }
    ]
  }
  ,

  { path: "", redirectTo: '/Login', pathMatch: 'full' },
  { path: "**", redirectTo: '/Login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
