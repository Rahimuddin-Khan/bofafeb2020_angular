import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RtgsComponent } from './rtgs/rtgs.component';
import { ImpsComponent } from './imps/imps.component';
import { NeftComponent } from './neft/neft.component';


const routes: Routes = [
  { path: "RTGS", component: RtgsComponent },
  { path: "IMPS", component: ImpsComponent },
  { path: "NEFT", component: NeftComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FundtransferRoutingModule { }
