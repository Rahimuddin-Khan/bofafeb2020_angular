import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-util',
  template: `
    <p>
      util works!
    </p>
  `,
  styles: []
})
export class UtilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
