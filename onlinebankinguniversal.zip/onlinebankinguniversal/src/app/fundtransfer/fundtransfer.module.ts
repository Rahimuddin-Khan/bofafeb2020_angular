import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FundtransferRoutingModule } from './fundtransfer-routing.module';
import { RtgsComponent } from './rtgs/rtgs.component';
import { NeftComponent } from './neft/neft.component';
import { ImpsComponent } from './imps/imps.component';



@NgModule({
  declarations: [RtgsComponent, NeftComponent, ImpsComponent],
  imports: [
    CommonModule,
    FundtransferRoutingModule
  ]
})
export class FundtransferModule { }
