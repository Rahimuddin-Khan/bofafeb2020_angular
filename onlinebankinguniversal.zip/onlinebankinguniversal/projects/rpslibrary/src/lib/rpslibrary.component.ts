import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-rpslibrary',
  template: `
    <p>
      rpslibrary works!
    </p>
  `,
  styles: []
})
export class RpslibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
