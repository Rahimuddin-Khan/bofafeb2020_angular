import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-rtgs',
  templateUrl: './rtgs.component.html',
  styleUrls: ['./rtgs.component.less']
})
export class RtgsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
