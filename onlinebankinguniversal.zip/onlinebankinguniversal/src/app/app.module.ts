import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { LoginModule } from './login/login.module';
import { MaterialModule } from './material/material.module';
import { HttpClientModule } from '@angular/common/http';
import { AuthenticationService } from './services/authentication.service';
import { HomeComponent } from './home/home/home.component';
import { MenuService } from './services/menu.service';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { MenuItem } from 'primeng/api';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { TransactionComponent } from './transaction/transaction.component';
import { ChequeComponent } from './cheque/cheque.component';
import { AddressComponent } from './address/address.component';
import { RequestComponent } from './request/request.component';
import { EditViewComponent } from './transaction/edit-view/edit-view.component';
import { EditComponent } from './transaction/edit/edit.component';
import { FooterComponent } from './footer/footer.component';
import { createCustomElement } from '@angular/elements';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { RpslibraryModule } from 'projects/rpslibrary/src/public-api';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AccountsummaryComponent,
    TransactionComponent,
    ChequeComponent,
    AddressComponent,
    RequestComponent,
    EditViewComponent,
    EditComponent,
    FooterComponent

  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    LoginModule,
    MaterialModule,
    HttpClientModule,
    TieredMenuModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    RpslibraryModule
  ],
  providers: [AuthenticationService, MenuService],
  entryComponents: [EditViewComponent, FooterComponent],
  bootstrap: [AppComponent],

})
export class AppModule {
  /**
   *
   */
  constructor(private injector: Injector) {
    // const e = createCustomElement(FooterComponent, { injector });
    // customElements.define("bofa-footer", e);
  }
}
