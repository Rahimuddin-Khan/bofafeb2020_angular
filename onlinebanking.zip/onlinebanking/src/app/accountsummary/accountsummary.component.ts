import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-accountsummary',
  templateUrl: './accountsummary.component.html',
  styleUrls: ['./accountsummary.component.less']
})
export class AccountsummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
