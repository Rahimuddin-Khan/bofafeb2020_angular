import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EditComponent } from '../edit/edit.component';

@Component({
  selector: 'bofa-edit-view',
  templateUrl: './edit-view.component.html',
  styleUrls: ['./edit-view.component.less']
})
export class EditViewComponent implements OnInit {

  constructor(private matDialogRef: MatDialogRef<EditComponent>, @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
  }
  onNoClick(): void {
    this.matDialogRef.close();
  }

}
