import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpslibraryComponent } from './rpslibrary.component';

describe('RpslibraryComponent', () => {
  let component: RpslibraryComponent;
  let fixture: ComponentFixture<RpslibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpslibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpslibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
