import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-neft',
  templateUrl: './neft.component.html',
  styleUrls: ['./neft.component.less']
})
export class NeftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
