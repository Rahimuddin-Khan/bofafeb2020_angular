import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../util/src/lib/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'admin';
  /**
   *
   */
  data: any;
  constructor(private userSvc: UserService) {


  }
  ngOnInit() {
    this.data = this.userSvc.getData();
    console.log(this.data)
  }
}
