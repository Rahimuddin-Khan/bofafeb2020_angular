import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bofa-imps',
  templateUrl: './imps.component.html',
  styleUrls: ['./imps.component.less']
})
export class ImpsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
