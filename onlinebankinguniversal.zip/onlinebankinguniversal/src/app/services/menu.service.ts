import { Injectable } from '@angular/core';
import { menus } from '../models/menudata';
import { of, Observable } from 'rxjs';
import { Menu } from '../models/menu';



@Injectable()
export class MenuService {

  constructor() { }
  getMenuItems(): Observable<Menu[]> {
    return of(menus);
  }
}
