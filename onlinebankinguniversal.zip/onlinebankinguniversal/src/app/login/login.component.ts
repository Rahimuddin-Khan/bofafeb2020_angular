import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { NgForm } from '@angular/forms';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'bofa-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {

  constructor(private loginSvc: LoginService, private router: Router, private authSvc: AuthenticationService) { }
  user: User = new User("eswaribala", "vignesh");
  ngOnInit() {
  }
  onSubmit(f: NgForm) {
    this.loginSvc.checkUserExistence(this.user).subscribe(x => {
      this.onReset();
      if (x.email != null) {
        this.authSvc.token = x.email;
        if (this.authSvc.isLoggedIn) {
          this.router.navigate(["/Home"]);
        }
        else
          this.router.navigate(["/Login"]);
      }
    }
    );
  }
  onReset() {
    this.user = new User('', '');
  }

}
