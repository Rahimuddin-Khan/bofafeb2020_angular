import { Menu, SubMenu } from "./menu";

export let menus: Array<Menu> = [
    new Menu('Account Summary', 'pi pi-fw pi-plus', 'AccountSummary',
        [
            new SubMenu('Transactions', 'pi pi-arrow-right', 'AccountSummary/Transactions')
        ]
    ),
    new Menu('Requests', 'pi pi-fw pi-plus', 'Requests',
        [
            new SubMenu('Cheque Request', 'pi pi-arrow-right', 'Requests/Cheque'),
            new SubMenu('Address Change', 'pi pi-arrow-right', 'Requests/Address')
        ]
    ),
    new Menu('Fund Transfer', 'pi pi-fw pi-plus', 'FT',
        [
            new SubMenu('NEFT', 'pi pi-arrow-right', 'FT/NEFT'),
            new SubMenu('RTGS', 'pi pi-arrow-right', 'FT/RTGS'),
            new SubMenu('IMPS', 'pi pi-arrow-right', 'FT/IMPS')
        ]
    ),
]


