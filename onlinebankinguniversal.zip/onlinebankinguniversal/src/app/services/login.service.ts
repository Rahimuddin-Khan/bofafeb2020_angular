import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable()
export class LoginService {

  constructor(private http: HttpClient) {

  }
  checkUserExistence(userObj: User): Observable<any> {
    return this.http.get(`https://daimalerblog2019-cf.cfapps.io/findboauserbyname/${userObj.userName}`);
  }
}
